# -*- coding: utf-8 -*-

# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html

import random
import requests
import time
from twisted.internet.defer import DeferredLock

class UserAgentDownloadMiddleware(object):
    USER_AGENTS = [
        'Mozilla/5.0 (X11; Linux i686; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194A',
        'Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5355d Safari/8536.25',
        'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.17 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
        'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:21.0) Gecko/20100101 Firefox/21.0',
        'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:21.0) Gecko/20130514 Firefox/21.0',
        'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36'
    ]
    def process_request(self,request,spider):
        user_agent=random.choice(self.USER_AGENTS)
        request.headers['User-Agent']=user_agent
        request.cookies={'cookie':'aQQ_ajkguid=AB04A35C-1332-7289-D75E-D186B3DBF2D6; 58tj_uuid=8e26bd90-24cb-46d9-9e52-79914305db21; als=0; isp=true; _ga=GA1.2.813101561.1584880770; wmda_uuid=ebbe560b344031f50d88d79a8787ef3a; wmda_new_uuid=1; Hm_lvt_c5899c8768ebee272710c9c5f365a6d8=1584801636,1585038728; wmda_visited_projects=%3B6145577459763%3B8797075781809; sessid=DF457BE8-1B17-06A4-9B33-CX0330221855; lps=http%3A%2F%2Fuser.anjuke.com%2Fajax%2FcheckMenu%2F%3Ff%3Dlogin%26r%3D0.6281925224232279%26callback%3DloginObj.successCallBack%7Chttps%3A%2F%2Fwww.anjuke.com%2Fcaptcha-verify%2F%3Fcallback%3Dshield%26from%3Dantispam%26namespace%3Danjuke_c_m%26serialID%3De0c5b5652704ffcd14742d529214cd6f_debfc1e3ba594b89b575e1c3f0690611%26history%3DaHR0cHM6Ly9tb2JpbGUuYW5qdWtlLmNvbS9mYW5namlhL2FucWluZy8%253D; twe=2; ctid=107; init_refer=; new_uv=30; new_session=0; _gid=GA1.2.115691401.1586150366; _gat=1; __xsptplusUT_8=1; __xsptplus8=8.19.1586150366.1586150366.1%233%7Ccn.58.com%7C%7C%7C%7C%23%23-M5eAOz48XrVFtNJyBkP14RlRWas3327%23; wmda_session_id_6145577459763=1586150371177-d995db53-d571-ef74; xzfzqtoken=z1QqHJRNBeGiPbOQ1IUlnLH8PFakSTV3p3jBAzyQ9l2pD3NXnxRFc9lTa8vW1pOHin35brBb%2F%2FeSODvMgkQULA%3D%3D'}

# 配置ip代理池
class IPProxyDownloadMiddleware(object):
    lock = DeferredLock()
    current_ip = ""
    def get_random_proxy(self):
        proxypool_url = 'http://39.100.105.212:5555/random'
        self.lock.acquire()
        self.current_ip = requests.get(proxypool_url).text.strip()
        self.lock.release()

    def process_response(self, request, response, spider):
        '''对返回的response处理'''
        # 如果返回的response状态不是200，重新生成当前request对象
        if response.status != 200:
            self.get_random_proxy()
            time.sleep(1)
            proxy = self.current_ip
                # print("this is response ip:" + proxy)
                # 对当前reque加上代理
            proxies = {"http": "https://" + proxy}
            request.meta['proxy'] = proxies
            print("当前ip已修改为：",proxy)
        return response

    def process_request(self,request,spider):
        '''对request对象加上proxy'''
        self.get_random_proxy()
        time.sleep(1)
        proxy = self.current_ip
        request.meta['proxy'] = "http://"+proxy
        print("this is request ip:" + proxy)
