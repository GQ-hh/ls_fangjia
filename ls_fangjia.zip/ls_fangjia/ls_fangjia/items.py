# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class LsFangjiaItem(scrapy.Item):
    province_name=scrapy.Field()
    city_name=scrapy.Field()
    dis_name=scrapy.Field()
    time=scrapy.Field()
    price=scrapy.Field()

class LsFangjiaItem2(scrapy.Item):
    province_name=scrapy.Field()

