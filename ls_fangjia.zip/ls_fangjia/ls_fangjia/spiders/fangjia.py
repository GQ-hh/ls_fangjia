# -*- coding: utf-8 -*-
import scrapy
from ls_fangjia.items import LsFangjiaItem


class FangjiaSpider(scrapy.Spider):
	name = 'fangjia'
	allowed_domains = ['mobile.anjuke.com/fangjia']
	start_urls = []

	def parse(self, response):
		province_name = response.xpath("//*[@id='price']/span/text()").get()
		#
		# 每个城市的链接
		a2_list = response.xpath("//div[@id='housetypeinfo']/div[@class='pricelist']")
		for a2 in a2_list:
			clist = a2.xpath(".//a")
			for c in clist:
				city_name = c.xpath(".//text()").get()
				#
				# 有一个全部的选项，不需要
				if city_name == "全部": continue
				city_url = c.xpath(".//@href").get()
				# print(province_name,city_name,city_url)
				yield scrapy.Request(url=city_url, callback=self.parse_dis,
									 meta={"info": (province_name, city_name, city_url)}, dont_filter=True)
				break
			break

	def parse_dis(self, response):
		province_name, city_name, city_url = response.meta.get("info")
		div_list = response.xpath("//div[@class='optionlist']/div[@id='rsswitchinfo']")
		# 每个行政区的链接
		for d in div_list:
			divs = d.xpath(".//div[@class='blockinfo' and @id!='blockinfo-0']")
			for div in divs:
				dis_url = div.xpath(".//div/a[@class='high']/@href").get()
				#
				# 在每个行政区链接里插入年份获得历史房价详情页
				b = dis_url.split("/")
				for i in range(2013, 2021):
					c = str(i)
					d = b[0] + '/' + b[1] + '/' + b[2] + '/' + b[3] + '/' + b[4] + c + '/' + b[5]
					# print(city_name,dis_name,d)
					#
					# 根据行政区链接请求行政区名字
					yield scrapy.Request(url=d, callback=self.parse_disname,
										 meta={"info": (province_name, city_name, d, city_url)}, dont_filter=True)

	def parse_disname(self, response):
		province_name, city_name, d, city_url = response.meta.get("info")
		# 行政区的名字
		div_list = response.xpath("//div[@class='optionlist']/div[@id='rsswitchinfo']")
		for d1 in div_list:
			lis = d1.xpath(".//div[@class='regioninfo']/ul[@class='regionlist']/li[@title!='全部' and @class='high']")
			for li in lis:
				dis_name = li.xpath(".//text()").get()
			# print(city_name,dis_name,d)
			yield scrapy.Request(url=d, callback=self.parse_detail, meta={"info": (province_name, city_name, dis_name)},
								 dont_filter=True)

	def parse_detail(self, response):
		province_name, city_name, dis_name = response.meta.get("info")
		# 获取历史房价详情
		detail = response.xpath("//div[7]/ul")
		for lis in detail:
			info = lis.xpath(".//li")
			for li in info:
				time = li.xpath(".//a/span[@class='item-1']/text()").get()
				price = li.xpath(".//a/span[@class='item-2']/text()").get()
				# print(province_name,city_name,dis_name,time,price)
				item = LsFangjiaItem(province_name=province_name, city_name=city_name, dis_name=dis_name, time=time,
									 price=price)
				yield item
